<?php
// modules/admin/dashboard.php
require_once '../../config/db_connect.php';
require_once '../../function/rate_function.php';
require_once '../../includes/header.php';

// Fetch rates from the database using our connected function
$rates = getAllRates();
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_admin.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Admin Analytics</h2>
                <div class="d-flex gap-2">
                    <span class="badge bg-dark p-2 px-3 rounded-pill">System Admin Portal</span>
                </div>
            </div>

            <div class="row g-4 mb-5">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm p-4">
                        <p class="text-muted small mb-1 text-uppercase fw-bold">Daily Volume</p>
                        <h2 class="fw-bold mb-0">14,280</h2>
                        <small class="text-success fw-bold">↑ 12.5% Growth</small>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm p-4">
                        <p class="text-muted small mb-1 text-uppercase fw-bold">Revenue (MTD)</p>
                        <h2 class="fw-bold mb-0">₱8.42M</h2>
                        <small class="text-success fw-bold">↑ 8.2% vs Last Month</small>
                    </div>
                </div>
            </div>

            <!-- Rate Management Section (Live Data) -->
            <div class="card border-0 shadow-sm p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="fw-bold mb-0">Rates & Tariff Control</h5>
                        <p class="text-muted small mb-0">Live rates fetched from `service_rates` table</p>
                    </div>
                    <a href="rates.php" class="btn btn-primary px-4 fw-bold">+ Add New Service</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light small text-muted">
                            <tr>
                                <th>SERVICE TYPE</th>
                                <th>BASE RATE</th>
                                <th>PER KG RATE</th>
                                <th class="text-end">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($rates as $r): ?>
                            <tr>
                                <td class="fw-bold"><?php echo htmlspecialchars($r['service_name']); ?></td>
                                <td>₱<?php echo number_format($r['base_rate'], 2); ?></td>
                                <td>₱<?php echo number_format($r['per_kg_rate'], 2); ?></td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-light border"><i data-lucide="edit-2" size="14"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
