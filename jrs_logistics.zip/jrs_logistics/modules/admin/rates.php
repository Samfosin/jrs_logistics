<?php
// functions/rate_function.php
require_once __DIR__ . '/../config/db_connect.php';

/**
 * Get all available service rates
 */
function getAllRates() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM service_rates ORDER BY base_rate ASC");
    return $stmt->fetchAll();
}

/**
 * Get a single rate by ID
 */
function getRateById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM service_rates WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Update a service rate
 */
function updateRate($id, $base, $per_kg) {
    global $pdo;
    $sql = "UPDATE service_rates SET base_rate = ?, per_kg_rate = ? WHERE id = ?";
    return $pdo->prepare($sql)->execute([$base, $per_kg, $id]);
}

/**
 * Add a new service rate
 */
function addRate($service_name, $base_rate, $per_kg_rate) {
    global $pdo;
    $sql = "INSERT INTO service_rates (service_name, base_rate, per_kg_rate) VALUES (?, ?, ?)";
    return $pdo->prepare($sql)->execute([$service_name, $base_rate, $per_kg_rate]);
}