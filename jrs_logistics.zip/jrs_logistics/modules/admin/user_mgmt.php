<?php
// modules/admin/user_mgmt.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';

// Mock users for the management view
$users = [
    ['id' => 101, 'name' => 'Pasig Hub Staff', 'email' => 'pasig@jrs.com', 'role' => 'branch', 'status' => 'approved'],
    ['id' => 102, 'name' => 'Cebu Branch', 'email' => 'cebu@jrs.com', 'role' => 'branch', 'status' => 'pending'],
    ['id' => 103, 'name' => 'Mateo Santos', 'email' => 'mateo@email.com', 'role' => 'client', 'status' => 'approved']
];
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_admin.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">User Management</h2>
                <button class="btn btn-primary">+ Add New Internal User</button>
            </div>

            <div class="card border-0 shadow-sm overflow-hidden">
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="px-4 py-3 border-0 small text-muted">USER</th>
                                <th class="py-3 border-0 small text-muted">ROLE</th>
                                <th class="py-3 border-0 small text-muted">STATUS</th>
                                <th class="py-3 border-0 small text-muted text-end px-4">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $u): ?>
                            <tr class="border-top">
                                <td class="px-4 py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary-container text-primary rounded-circle p-2 me-3" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                                            <i data-lucide="user" size="18"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo $u['name']; ?></div>
                                            <small class="text-muted"><?php echo $u['email']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3"><span class="badge bg-light text-dark text-capitalize px-3"><?php echo $u['role']; ?></span></td>
                                <td class="py-3">
                                    <?php if($u['status'] == 'approved'): ?>
                                        <span class="badge bg-success-subtle text-success px-3">● ACTIVE</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning px-3">● PENDING APPROVAL</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 text-end px-4">
                                    <button class="btn btn-sm btn-outline-dark me-1"><i data-lucide="edit-2" size="14"></i></button>
                                    <button class="btn btn-sm btn-outline-danger"><i data-lucide="trash-2" size="14"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
