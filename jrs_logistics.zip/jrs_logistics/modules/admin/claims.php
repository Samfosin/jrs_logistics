<?php
// modules/admin/claims.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_admin.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <h2 class="fw-bold mb-4">Claims & Disputes Oversight</h2>

            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 bg-white">
                        <p class="text-muted small mb-1">PENDING CLAIMS</p>
                        <h2 class="fw-black text-warning mb-0">24</h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 bg-white">
                        <p class="text-muted small mb-1">TOTAL PAYOUTS (MTD)</p>
                        <h2 class="fw-black text-primary mb-0">₱125,400</h2>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="bg-light small text-muted">
                            <tr>
                                <th class="px-4">CLAIM ID</th>
                                <th>CLIENT</th>
                                <th>TYPE</th>
                                <th>AMOUNT CLAIMED</th>
                                <th>STATUS</th>
                                <th class="text-end px-4">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-top">
                                <td class="px-4 fw-bold">CLM-2024-001</td>
                                <td>Mateo Santos</td>
                                <td>Damaged Item</td>
                                <td class="fw-bold">₱1,200.00</td>
                                <td><span class="badge bg-warning-subtle text-warning">PENDING REVIEW</span></td>
                                <td class="text-end px-4">
                                    <button class="btn btn-sm btn-outline-primary">Review</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
