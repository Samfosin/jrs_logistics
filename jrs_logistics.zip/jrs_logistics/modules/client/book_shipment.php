<?php
// modules/client/book_shipment.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_client.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="max-w-4xl mx-auto">
                <h2 class="fw-bold mb-1">Create New Shipment</h2>
                <p class="text-muted mb-5">Book your package for pickup or drop-off in just a few steps.</p>

                <!-- Stepper Visual -->
                <div class="stepper mb-5">
                    <div class="step active"><div class="step-circle">1</div><small class="fw-bold">SENDER</small></div>
                    <div class="step"><div class="step-circle">2</div><small>RECEIVER</small></div>
                    <div class="step"><div class="step-circle">3</div><small>PACKAGE</small></div>
                    <div class="step"><div class="step-circle">4</div><small>REVIEW</small></div>
                </div>

                <form class="card border-0 shadow-sm p-4">
                    <h5 class="fw-bold mb-4 border-bottom pb-3"><i data-lucide="user" class="me-2"></i>Sender Information</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">Full Name</label>
                            <input type="text" class="form-control form-control-lg bg-light border-0" value="John Doe">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">Phone Number</label>
                            <input type="text" class="form-control form-control-lg bg-light border-0" value="+63 917 123 4567">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">Pickup Address</label>
                            <textarea class="form-control bg-light border-0" rows="3">Unit 402, High-Rise Towers, Ayala Ave, Makati City, Metro Manila, 1226</textarea>
                        </div>
                    </div>

                    <h5 class="fw-bold mb-4 border-bottom pb-3"><i data-lucide="user-plus" class="me-2"></i>Receiver Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">Recipient Full Name</label>
                            <input type="text" class="form-control form-control-lg bg-light border-0" placeholder="Enter name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">Recipient Phone</label>
                            <input type="text" class="form-control form-control-lg bg-light border-0" placeholder="+63 9XX XXX XXXX">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">Delivery Address</label>
                            <input type="text" class="form-control bg-light border-0 mb-3" placeholder="Street Name, Building, House No.">
                            <div class="row g-2">
                                <div class="col-md-8"><input type="text" class="form-control bg-light border-0" placeholder="City/Municipality"></div>
                                <div class="col-md-4"><input type="text" class="form-control bg-light border-0" placeholder="Postal Code"></div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-dark px-4 py-2">Save as Draft</button>
                        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold">Proceed to Package Details <i data-lucide="arrow-right" class="ms-2"></i></button>
                    </div>
                </form>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
