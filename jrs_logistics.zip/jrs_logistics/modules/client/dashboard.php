<?php
// modules/client/dashboard.php
require_once '../../config/db_connect.php';
require_once '../../functions/auth_functions.php';
require_once '../../functions/shipment_functions.php';

// Mock session for preview
if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_name'] = $_SESSION['user_name'] ?? 'Mateo Santos';
$_SESSION['user_id'] = $_SESSION['user_id'] ?? 1;

require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_client.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Overview</h2>
                <div class="d-flex gap-2">
                    <div class="input-group" style="width: 300px;">
                        <span class="input-group-text bg-white border-end-0"><i data-lucide="search" size="18"></i></span>
                        <input type="text" class="form-control border-start-0" placeholder="Search shipments...">
                    </div>
                    <button class="btn btn-white border rounded-circle"><i data-lucide="bell" size="18"></i></button>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="row g-3 mb-4">
                <?php
                $stats = [
                    ['label' => 'Active Shipments', 'val' => '12', 'icon' => 'truck', 'color' => 'primary'],
                    ['label' => 'Delivered', 'val' => '148', 'icon' => 'check-circle', 'color' => 'info'],
                    ['label' => 'Pending Pickups', 'val' => '03', 'icon' => 'package', 'color' => 'warning'],
                    ['label' => 'Total Spent', 'val' => '₱14.2k', 'icon' => 'credit-card', 'color' => 'success']
                ];
                foreach($stats as $s): ?>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-<?php echo $s['color']; ?> bg-opacity-10 text-<?php echo $s['color']; ?> p-3 rounded-3">
                                <i data-lucide="<?php echo $s['icon']; ?>"></i>
                            </div>
                            <div>
                                <small class="text-muted d-block"><?php echo $s['label']; ?></small>
                                <h4 class="fw-bold mb-0"><?php echo $s['val']; ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold mb-0">Recent Shipments</h5>
                            <a href="#" class="text-primary text-decoration-none small">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-middle">
                                <thead class="text-muted small">
                                    <tr>
                                        <th>TRACKING ID</th>
                                        <th>DESTINATION</th>
                                        <th>STATUS</th>
                                        <th>DATE</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bold text-primary">JRS-9283-001</td>
                                        <td>Cebu City, Cebu</td>
                                        <td><span class="badge bg-info-subtle text-info px-3">IN TRANSIT</span></td>
                                        <td class="text-muted small">Oct 24, 2024</td>
                                    </tr>
                                    <!-- More rows... -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-primary text-white border-0 p-4 mb-4">
                        <h5 class="fw-bold"><i data-lucide="map-pin" class="me-2"></i>Track Parcel</h5>
                        <p class="small opacity-75">Enter your 9-digit JRS tracking number</p>
                        <div class="input-group">
                            <input type="text" class="form-control border-0" placeholder="e.g. 123456789">
                            <button class="btn btn-light"><i data-lucide="arrow-right"></i></button>
                        </div>
                    </div>
                    <a href="book_shipment.php" class="btn btn-primary w-100 py-3 fw-bold rounded-3 shadow-sm">
                        <i data-lucide="plus" class="me-2"></i>New Shipment
                    </a>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
<?php
// modules/client/dashboard.php
require_once '../../config/db_connect.php';
require_once '../../functions/auth_functions.php';
require_once '../../functions/shipment_functions.php';

// Mock session for preview
if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_name'] = $_SESSION['user_name'] ?? 'Mateo Santos';
$_SESSION['user_id'] = $_SESSION['user_id'] ?? 1;

require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_client.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Overview</h2>
                <div class="d-flex gap-2">
                    <div class="input-group" style="width: 300px;">
                        <span class="input-group-text bg-white border-end-0"><i data-lucide="search" size="18"></i></span>
                        <input type="text" class="form-control border-start-0" placeholder="Search shipments...">
                    </div>
                    <button class="btn btn-white border rounded-circle"><i data-lucide="bell" size="18"></i></button>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="row g-3 mb-4">
                <?php
                $stats = [
                    ['label' => 'Active Shipments', 'val' => '12', 'icon' => 'truck', 'color' => 'primary'],
                    ['label' => 'Delivered', 'val' => '148', 'icon' => 'check-circle', 'color' => 'info'],
                    ['label' => 'Pending Pickups', 'val' => '03', 'icon' => 'package', 'color' => 'warning'],
                    ['label' => 'Total Spent', 'val' => '₱14.2k', 'icon' => 'credit-card', 'color' => 'success']
                ];
                foreach($stats as $s): ?>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-<?php echo $s['color']; ?> bg-opacity-10 text-<?php echo $s['color']; ?> p-3 rounded-3">
                                <i data-lucide="<?php echo $s['icon']; ?>"></i>
                            </div>
                            <div>
                                <small class="text-muted d-block"><?php echo $s['label']; ?></small>
                                <h4 class="fw-bold mb-0"><?php echo $s['val']; ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold mb-0">Recent Shipments</h5>
                            <a href="#" class="text-primary text-decoration-none small">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-middle">
                                <thead class="text-muted small">
                                    <tr>
                                        <th>TRACKING ID</th>
                                        <th>DESTINATION</th>
                                        <th>STATUS</th>
                                        <th>DATE</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bold text-primary">JRS-9283-001</td>
                                        <td>Cebu City, Cebu</td>
                                        <td><span class="badge bg-info-subtle text-info px-3">IN TRANSIT</span></td>
                                        <td class="text-muted small">Oct 24, 2024</td>
                                    </tr>
                                    <!-- More rows... -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-primary text-white border-0 p-4 mb-4">
                        <h5 class="fw-bold"><i data-lucide="map-pin" class="me-2"></i>Track Parcel</h5>
                        <p class="small opacity-75">Enter your 9-digit JRS tracking number</p>
                        <div class="input-group">
                            <input type="text" class="form-control border-0" placeholder="e.g. 123456789">
                            <button class="btn btn-light"><i data-lucide="arrow-right"></i></button>
                        </div>
                    </div>
                    <a href="book_shipment.php" class="btn btn-primary w-100 py-3 fw-bold rounded-3 shadow-sm">
                        <i data-lucide="plus" class="me-2"></i>New Shipment
                    </a>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
