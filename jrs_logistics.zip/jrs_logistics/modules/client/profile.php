<?php
// modules/client/profile.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';

// Mock user data
$user = [
    'name' => 'Mateo Santos',
    'email' => 'mateo@email.com',
    'phone' => '+63 917 123 4567',
    'address' => 'Unit 402, High-Rise Towers, Ayala Ave, Makati City'
];
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_client.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="max-w-3xl mx-auto">
                <h2 class="fw-bold mb-4">My Profile</h2>
                
                <div class="card border-0 shadow-sm p-4 mb-4">
                    <div class="d-flex align-items-center mb-4">
                        <img src="https://ui-avatars.com/api/?name=Mateo+Santos&background=ee4d2d&color=fff&size=80" class="rounded-circle me-4 shadow-sm" alt="Avatar">
                        <div>
                            <h4 class="fw-bold mb-1"><?php echo $user['name']; ?></h4>
                            <p class="text-muted mb-0">Client Account #JRS-USR-8821</p>
                        </div>
                    </div>

                    <form>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Full Name</label>
                                <input type="text" class="form-control bg-light border-0 py-2" value="<?php echo $user['name']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Email Address</label>
                                <input type="email" class="form-control bg-light border-0 py-2" value="<?php echo $user['email']; ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Phone Number</label>
                                <input type="text" class="form-control bg-light border-0 py-2" value="<?php echo $user['phone']; ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Default Pickup Address</label>
                                <textarea class="form-control bg-light border-0" rows="3"><?php echo $user['address']; ?></textarea>
                            </div>
                        </div>
                        <hr class="my-4">
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary px-5 fw-bold py-2">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
