<?php
// modules/client/waybill_pdf.php
// Note: In a production environment, you would use a library like Dompdf or TCPDF.
// This version uses a print-optimized HTML layout designed to be saved as PDF.

require_once '../../config/db_connect.php';
require_once '../../functions/shipment_functions.php';
require_once '../../functions/utility_functions.php';

$tracking = $_GET['id'] ?? 'JRS-9283-001';
$shipment = getShipmentByTracking($tracking);

if (!$shipment) {
    die("Shipment not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Waybill - <?php echo $tracking; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
            body { padding: 0; background: white; }
            .waybill-card { border: 2px solid #000 !important; box-shadow: none !important; }
        }
        body { background-color: #f8f9fa; font-family: 'Inter', sans-serif; }
        .waybill-card {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border: 1px solid #dee2e6;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .label-header {
            background: #ee4d2d;
            color: white;
            padding: 20px;
        }
        .barcode-placeholder {
            font-family: 'Libre Barcode 39', cursive;
            font-size: 60px;
            text-align: center;
            border: 1px dashed #ccc;
            padding: 10px;
            background: #fff;
        }
        .qr-placeholder {
            width: 100px;
            height: 100px;
            background: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #ddd;
        }
        .data-section { border-bottom: 1px solid #eee; padding: 15px 0; }
        .data-label { font-size: 10px; font-weight: bold; color: #888; text-transform: uppercase; }
        .data-value { font-size: 14px; font-weight: bold; color: #000; }
    </style>
    <!-- Google Font for Barcode Simulation if needed -->
    <link href="https://fonts.googleapis.com/css2?family=Libre+Barcode+39&display=swap" rel="stylesheet">
</head>
<body>

<div class="container no-print mt-4 text-center">
    <button onclick="window.print()" class="btn btn-primary btn-lg px-5 fw-bold">
        <i data-lucide="printer" class="me-2"></i> Print / Save as PDF
    </button>
    <p class="mt-2 text-muted small">Tip: In the print dialog, set "Destination" to "Save as PDF"</p>
</div>

<div class="waybill-card">
    <div class="label-header d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-black mb-0">JRS EXPRESS</h2>
            <p class="mb-0 opacity-75 small">Established 1960</p>
        </div>
        <div class="text-end">
            <h4 class="mb-0 fw-bold">OFFICIAL WAYBILL</h4>
            <p class="mb-0 small">Customer Copy</p>
        </div>
    </div>

    <div class="p-4">
        <div class="row mb-4">
            <div class="col-8">
                <div class="barcode-placeholder mb-2">
                    *<?php echo $shipment['tracking_number']; ?>*
                </div>
                <div class="text-center fw-bold letter-spacing-1"><?php echo $shipment['tracking_number']; ?></div>
            </div>
            <div class="col-4 d-flex justify-content-end">
                <div class="qr-placeholder text-center small">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=<?php echo $shipment['tracking_number']; ?>" alt="QR Code">
                </div>
            </div>
        </div>

        <div class="row g-0">
            <div class="col-md-6 border-end pe-4">
                <div class="data-section">
                    <div class="data-label">Sender</div>
                    <div class="data-value"><?php echo $_SESSION['user_name'] ?? 'Mateo Santos'; ?></div>
                </div>
                <div class="data-section">
                    <div class="data-label">Origin Address</div>
                    <div class="data-value small">Unit 402, High-Rise Towers, Ayala Ave, Makati City, 1226</div>
                </div>
                <div class="data-section">
                    <div class="data-label">Contact</div>
                    <div class="data-value">+63 917 123 4567</div>
                </div>
            </div>
            <div class="col-md-6 ps-4">
                <div class="data-section">
                    <div class="data-label">Receiver</div>
                    <div class="data-value"><?php echo $shipment['receiver_name']; ?></div>
                </div>
                <div class="data-section">
                    <div class="data-label">Destination Address</div>
                    <div class="data-value small"><?php echo $shipment['destination_address']; ?></div>
                </div>
                <div class="data-section">
                    <div class="data-label">Contact</div>
                    <div class="data-value"><?php echo $shipment['receiver_phone']; ?></div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-3">
                <div class="p-3 bg-light rounded text-center border">
                    <div class="data-label">Weight</div>
                    <div class="data-value"><?php echo $shipment['weight']; ?> KG</div>
                </div>
            </div>
            <div class="col-3">
                <div class="p-3 bg-light rounded text-center border">
                    <div class="data-label">Service</div>
                    <div class="data-value text-uppercase"><?php echo $shipment['service_name']; ?></div>
                </div>
            </div>
            <div class="col-6">
                <div class="p-3 bg-dark text-white rounded text-center">
                    <div class="data-label text-white-50">Total Paid (VAT Inc.)</div>
                    <div class="h4 mb-0 fw-black"><?php echo formatPHP($shipment['total_cost']); ?></div>
                </div>
            </div>
        </div>

        <div class="mt-4 p-3 border rounded">
            <div class="row">
                <div class="col-8 small text-muted">
                    <p class="mb-1"><strong>Terms & Conditions:</strong></p>
                    <p class="mb-0" style="font-size: 9px;">The carrier's liability is limited to ₱500 unless a higher value is declared and insurance is paid. JRS Express is not liable for indirect or consequential damages. By signing, the sender agrees to all terms found at jrs-express.com/terms.</p>
                </div>
                <div class="col-4 border-start text-center d-flex flex-column justify-content-end">
                    <div class="border-top pt-2 mt-4 small fw-bold">Sender Signature</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="bg-light p-3 text-center border-top">
        <small class="text-muted">Generated by JRS Logistics Portal on <?php echo date('M d, Y H:i'); ?></small>
    </div>
</div>

<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
</body>
</html>
