<?php
// modules/client/history.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0"><?php include '../../includes/sidebar_client.php'; ?></div>
        <main class="col p-4 bg-light min-vh-100">
            <h2 class="fw-bold mb-4">Shipment History</h2>
            <div class="card border-0 shadow-sm p-4">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tracking ID</th>
                            <th>Receiver</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>JRS-8234-XYZ</strong></td>
                            <td>Maria Clara</td>
                            <td><span class="badge bg-success">DELIVERED</span></td>
                            <td>Oct 20, 2024</td>
                            <td><a href="waybill_print.php" class="btn btn-sm btn-outline-primary">View</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>