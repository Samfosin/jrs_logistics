<?php
// modules/client/claims.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_client.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="max-w-4xl mx-auto">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold mb-0">Insurance & Claims</h2>
                    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#claimModal">
                        <i data-lucide="shield-alert" class="me-2"></i> File a New Claim
                    </button>
                </div>

                <div class="card border-0 shadow-sm p-4">
                    <h5 class="fw-bold mb-4">My Claims History</h5>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead class="text-muted small">
                                <tr>
                                    <th>CLAIM ID</th>
                                    <th>TRACKING #</th>
                                    <th>TYPE</th>
                                    <th>STATUS</th>
                                    <th>FILED ON</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="fw-bold">CLM-2024-001</td>
                                    <td>JRS-8234-XYZ</td>
                                    <td>Damaged Item</td>
                                    <td><span class="badge bg-warning-subtle text-warning px-3">UNDER REVIEW</span></td>
                                    <td>Oct 25, 2024</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Claim Modal -->
<div class="modal fade" id="claimModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 p-4">
                <h5 class="modal-title fw-bold">File a Dispute / Insurance Claim</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 pt-0">
                <form>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Tracking Number</label>
                            <input type="text" class="form-control bg-light border-0" placeholder="e.g. JRS-XXXX-XXX">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Claim Type</label>
                            <select class="form-select bg-light border-0">
                                <option>Damaged Item</option>
                                <option>Lost Parcel</option>
                                <option>Incorrect Delivery</option>
                                <option>Other Dispute</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Description of Issue</label>
                            <textarea class="form-control bg-light border-0" rows="4" placeholder="Explain what happened in detail..."></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Upload Proof (Photos of damaged item/receipt)</label>
                            <input type="file" class="form-control bg-light border-0">
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary px-4 fw-bold">Submit Claim</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
