<!--?php
/**
 * JRS Logistics - Login Page
 * Path: modules/auth/login.php
 */

// 1. Absolute path detection for fixing 'Failed to open stream' error
$project_root = dirname(dirname(__DIR__));

// 2. Include singular file name for functions as requested
require_once $project_root . '/functions/auth_function.php';

// Include header using absolute project root
include_once $project_root . '/includes/header.php';
?--><!DOCTYPE html>

<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Login | JRS Logistics</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script id="tailwind-config">
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            "colors": {
                    "primary": "#ee4d2d", // Shopee Orange
                    "primary-hover": "#d73211",
                    "surface-container-low": "#fff0ee",
                    "on-surface": "#271815",
                    "on-surface-variant": "#5b403b",
                    "outline": "#8f7069",
                    "outline-variant": "#e3beb6",
                    "background": "#fff8f6",
                    "surface": "#fff8f6"
            },
            "borderRadius": {
                    "DEFAULT": "0.125rem",
                    "lg": "0.25rem",
                    "xl": "0.5rem",
                    "full": "0.75rem"
            }
          },
        },
      }
    </script>
<style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        .login-gradient {
            background: linear-gradient(135deg, #b22204 0%, #ee4d2d 100%);
        }
    </style>
</head>
<body class="bg-background text-on-surface min-h-screen">
<main class="min-h-screen flex flex-col md:flex-row">
<!-- 3. Professional Split-Screen Layout: Brand Side (Left) -->
<div class="hidden md:flex md:w-1/2 login-gradient items-center justify-center p-12 text-white relative overflow-hidden">
<div class="relative z-10 max-w-md">
<h1 class="text-4xl font-bold mb-6 tracking-tight">JRS LOGISTICS</h1>
<p class="text-xl opacity-90 mb-8 leading-relaxed">
                Industrial Heritage meets Modern Speed. 
                Log in to manage your shipments with the efficiency you deserve.
            </p>
<div class="space-y-6">
<div class="flex items-center gap-4">
<span class="material-symbols-outlined bg-white/20 p-2 rounded-full">speed</span>
<span class="text-lg">Real-time tracking and analytics</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined bg-white/20 p-2 rounded-full">security</span>
<span class="text-lg">Secure enterprise-grade logistics</span>
</div>
<div class="flex items-center gap-4">
<span class="material-symbols-outlined bg-white/20 p-2 rounded-full">hub</span>
<span class="text-lg">Network of 400+ branches</span>
</div>
</div>
</div>
<!-- Decorative background element -->
<div class="absolute bottom-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mb-20 blur-3xl"></div>
<div class="absolute top-0 left-0 w-64 h-64 bg-black/10 rounded-full -ml-20 -mt-20 blur-3xl"></div>
</div>
<!-- 3. Professional Split-Screen Layout: Form Side (Right) -->
<div class="flex-1 flex items-center justify-center p-6 md:p-12 bg-white">
<div class="w-full max-w-md">
<div class="md:hidden mb-8">
<h1 class="text-2xl font-bold text-primary tracking-tighter">JRS LOGISTICS</h1>
</div>
<div class="mb-8">
<h2 class="text-3xl font-bold text-on-surface mb-2">Welcome Back</h2>
<p class="text-on-surface-variant">Please enter your details to sign in.</p>
</div>
<form ?="" action="&lt;?php echo htmlspecialchars($_SERVER[" php_self"]);="">" class="space-y-5" method="POST"&gt;
                <div>
<label class="block text-sm font-medium text-on-surface-variant mb-1.5" for="email">Email Address</label>
<div class="relative">
<span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-lg">mail</span>
<input class="w-full pl-10 pr-4 py-3 border border-outline-variant rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-all bg-surface" id="email" name="email" placeholder="name@company.com" required="" type="email"/>
</div>
</div>
<div>
<div class="flex justify-between items-center mb-1.5">
<label class="block text-sm font-medium text-on-surface-variant" for="password">Password</label>
<a class="text-sm font-semibold text-primary hover:underline" href="forgot-password.php">Forgot password?</a>
</div>
<div class="relative">
<span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-lg">lock</span>
<input class="w-full pl-10 pr-4 py-3 border border-outline-variant rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-all bg-surface" id="password" name="password" placeholder="••••••••" required="" type="password"/>
</div>
</div>
<div class="flex items-center">
<input class="h-4 w-4 text-primary border-outline-variant rounded focus:ring-primary" id="remember" name="remember" type="checkbox"/>
<label class="ml-2 block text-sm text-on-surface-variant" for="remember">Remember me for 30 days</label>
</div>
<!-- 4. Shopee Orange Primary Action -->
<button class="w-full bg-primary text-white py-3.5 rounded-lg font-bold text-lg hover:bg-primary-hover transition-colors shadow-lg shadow-primary/20 active:scale-[0.98]" type="submit">
                    Sign In
                </button>
</form>
<p class="mt-8 text-center text-on-surface-variant">
                Don't have an account? 
                <a class="font-bold text-primary hover:underline" href="register.php">Contact your administrator</a>
</p>
</div>
</div>
</main>
<!--?php 
// 5. Include footer using absolute project root
include_once $project_root . '/includes/footer.php'; 
?-->
</body></html>