<?php
// modules/auth/register.php
require_once '../../config/db_connect.php';
require_once '../../functions/auth_functions.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    if (registerUser($name, $email, $password)) {
        header("Location: login.php?msg=registered");
        exit();
    } else {
        $error = "Registration failed. Email may already exist.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - JRS Logistics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">
    <div class="card shadow border-0" style="max-width: 500px; width: 100%;">
        <div class="p-5">
            <h2 class="fw-bold text-center mb-4">Create Account</h2>
            <?php if($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-3 fw-bold">Sign Up</button>
            </form>
            <p class="text-center mt-4">Already have an account? <a href="login.php" class="text-primary fw-bold">Login</a></p>
        </div>
    </div>
</body>
</html>