<?php
// modules/branch/reports.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_branch.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Daily Transaction Logs</h2>
                <div class="d-flex gap-2">
                    <input type="date" class="form-control border-0 shadow-sm" value="<?php echo date('Y-m-d'); ?>">
                    <button class="btn btn-primary px-4 fw-bold">Generate PDF</button>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 bg-white">
                        <p class="text-muted small mb-1">TOTAL CASH ON HAND</p>
                        <h2 class="fw-black text-primary mb-0">₱42,550.00</h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 bg-white">
                        <p class="text-muted small mb-1">TRANSACTIONS TODAY</p>
                        <h2 class="fw-black mb-0">156</h2>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm overflow-hidden">
                <table class="table align-middle mb-0">
                    <thead class="bg-light small fw-bold text-muted">
                        <tr>
                            <th class="px-4">TIME</th>
                            <th>TRACKING #</th>
                            <th>SERVICE</th>
                            <th>AMOUNT</th>
                            <th class="text-end px-4">PAYMENT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="px-4 small">09:15 AM</td>
                            <td class="fw-bold">JRS-9283-001</td>
                            <td>Express Letter</td>
                            <td class="fw-bold">₱120.00</td>
                            <td class="text-end px-4"><span class="badge bg-success-subtle text-success">CASH</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
