<?php
// modules/branch/dispatch.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_branch.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <h2 class="fw-bold mb-4">Dispatch & Master Bagging</h2>
            
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm p-4 mb-4">
                        <h5 class="fw-bold mb-4">Current Staging Area</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="small text-muted">
                                    <tr>
                                        <th>PARCEL ID</th>
                                        <th>DESTINATION</th>
                                        <th>WEIGHT</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bold">JRS-4421-BAG</td>
                                        <td>Manila North Hub</td>
                                        <td>2.5 kg</td>
                                        <td><button class="btn btn-sm btn-primary">Add to Bag</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm p-4 bg-white border-primary border-2">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold mb-0">Active Master Bag</h5>
                            <span class="badge bg-primary">OPEN</span>
                        </div>
                        <div class="mb-4">
                            <label class="small fw-bold text-muted">BAG ID</label>
                            <h4 class="fw-black text-primary">MB-2024-XP-002</h4>
                        </div>
                        <div class="mb-4">
                            <label class="small fw-bold text-muted">DESTINATION HUB</label>
                            <select class="form-select border-0 bg-light">
                                <option>Main Sorting Center (MIA)</option>
                                <option>Cebu Hub</option>
                                <option>Davao Regional</option>
                            </select>
                        </div>
                        <div class="py-3 border-top border-bottom mb-4">
                            <div class="d-flex justify-content-between small mb-1 text-muted">
                                <span>Total Parcels:</span>
                                <span class="fw-bold text-dark">0</span>
                            </div>
                            <div class="d-flex justify-content-between small text-muted">
                                <span>Total Weight:</span>
                                <span class="fw-bold text-dark">0.00 kg</span>
                            </div>
                        </div>
                        <button class="btn btn-dark w-100 py-3 fw-bold shadow-sm">SEAL & DISPATCH BAG</button>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
