<?php
// modules/branch/dashboard.php
require_once '../../config/db_connect.php';
require_once '../../function/shipment_function.php';
require_once '../../includes/header.php';

// Check for session to show user info
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0 d-none d-md-block">
            <?php include '../../includes/sidebar_branch.php'; ?>
        </div>
        <main class="col p-4 bg-light min-vh-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold text-primary mb-0">Branch Management</h2>
                    <small class="text-success fw-medium">● Connected: <?php echo $_SESSION['user_name'] ?? 'Branch Operator'; ?></small>
                </div>
                <div class="d-flex gap-3">
                    <form action="../../index.php" method="GET" class="d-flex gap-2">
                        <input type="text" name="tracking" class="form-control bg-white" placeholder="Lookup Tracking ID...">
                        <button type="submit" class="btn btn-outline-primary"><i data-lucide="search"></i></button>
                    </form>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 h-100">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1 text-uppercase fw-bold">Parcels Staged</p>
                                <h2 class="fw-bold mb-0">124</h2>
                                <small class="text-primary">Awaiting Dispatch</small>
                            </div>
                            <div class="bg-primary-container text-primary p-3 rounded-3">
                                <i data-lucide="package"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-4 h-100">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1 text-uppercase fw-bold">Total Dispatched</p>
                                <h2 class="fw-bold mb-0">842</h2>
                                <small class="text-success">Month-to-Date</small>
                            </div>
                            <div class="bg-success-subtle text-success p-3 rounded-3">
                                <i data-lucide="truck"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 p-4">
                    <h5 class="fw-bold mb-0">Quick Inventory Management</h5>
                </div>
                <div class="table-responsive px-4 pb-4">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light small text-muted">
                            <tr>
                                <th>TRACKING ID</th>
                                <th>RECIPIENT</th>
                                <th>STATUS</th>
                                <th class="text-end">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="fw-bold">JRS-98234-X</td>
                                <td>Maria Santos</td>
                                <td><span class="badge bg-info-subtle text-info px-3">AT BRANCH</span></td>
                                <td class="text-end">
                                    <a href="inventory.php" class="btn btn-sm btn-outline-dark">Update Status</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>
