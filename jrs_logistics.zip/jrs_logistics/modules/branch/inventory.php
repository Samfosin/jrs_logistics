<?php
// modules/branch/inventory.php
require_once '../../config/db_connect.php';
require_once '../../includes/header.php';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-auto p-0"><?php include '../../includes/sidebar_branch.php'; ?></div>
        <main class="col p-4 bg-light min-vh-100">
            <h2 class="fw-bold mb-4">Branch Inventory</h2>
            <div class="card border-0 shadow-sm p-4">
                <div class="mb-3"><input type="text" class="form-control w-25" placeholder="Search by ID..."></div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Parcel ID</th>
                            <th>Current Status</th>
                            <th>Location</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>JRS-98234-X</td>
                            <td><span class="badge bg-info">SORTING</span></td>
                            <td>PASIG HUB</td>
                            <td><button class="btn btn-sm btn-primary">Update Status</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>