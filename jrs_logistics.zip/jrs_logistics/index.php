<!DOCTYPE html>

<html lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>JRS Logistics - Reliability Beyond Borders</title>
<!-- Tailwind CSS v3 CDN -->
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<!-- Google Fonts: Inter -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              orange: '#ee4d2d',
              dark: '#1a1a1a',
              gray: '#f5f5f5',
            }
          },
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
          }
        }
      }
    }
  </script>
<style data-purpose="custom-utilities">
    .hero-overlay {
      background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.6));
    }
    .stepper-line {
      height: 2px;
      background: #e5e7eb;
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      transform: translateY(-50%);
      z-index: 0;
    }
    .stepper-line-active {
      background: #ee4d2d;
      width: 50%;
    }
    .shadow-card {
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }
    /* Fixed scroll and cursor issues */
    html, body {
      cursor: auto !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
      height: auto !important;
    }
  </style>
</head>
<body class="font-sans bg-white text-gray-900">
<!-- BEGIN: Top Navigation -->
<header class="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
<nav class="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
<div class="flex items-center gap-12">
<h1 class="text-2xl font-extrabold text-brand-orange tracking-tight">JRS LOGISTICS</h1>
<div class="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
<a class="text-brand-orange" href="#">Home</a>
<a class="hover:text-brand-orange transition" href="#">Branch Locator</a>
<a class="hover:text-brand-orange transition" href="#">Rates</a>
<a class="hover:text-brand-orange transition" href="#">Support</a>
</div>
</div>
<div class="flex items-center gap-4">
<div class="relative hidden lg:block">
<input class="pl-3 pr-10 py-1.5 border border-gray-200 rounded-md text-sm focus:ring-brand-orange focus:border-brand-orange" placeholder="Search..." type="text"/>
<svg class="w-4 h-4 absolute right-3 top-2.5 text-gray-400" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
</div>
<a class="bg-brand-orange text-white px-6 py-2 rounded font-bold text-sm hover:bg-orange-600 transition inline-block" href="/login">Log In</a>
</div>
</nav>
</header>
<!-- END: Top Navigation -->
<main>
<!-- BEGIN: Hero Section -->
<section class="relative bg-gray-900 min-h-[600px] flex items-center">
<!-- Hero Background -->
<div class="absolute inset-0 z-0">
<img alt="Logistics Background" class="w-full h-full object-cover opacity-50" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBDUSRIkDQuY4h7glVIZV58oRX7fI_OHfyFmNzeIvjbGiURY8Yie9AUMXfrLRMeKPkVSaJlWk3FhKgzpe6MxdSyTYTmtRO5B_KA3QiYSoRbB7nuUeeuDOk07E2eyXpD12576F1AHwBkf7tXy8xlnv2gPfTFzlFgzQTu-eOwjZVQ0otW6pFFSC7nX8pavBUOTRVAwnaJ7BqsdqMc5BTL3FaHbeN6h6iNEk0qeMmZCfcl54ggs4J67efsor_M4zARBBRAaTamdgZf"/>
<div class="absolute inset-0 hero-overlay"></div>
</div>
<div class="relative z-10 max-w-7xl mx-auto px-4 w-full grid lg:grid-cols-2 gap-12 py-16 items-center">
<!-- Left Side: Branding & Tracking -->
<div class="flex flex-col text-white">
<h2 class="text-4xl lg:text-5xl font-black mb-6 leading-tight uppercase">Reliability Beyond<br/>Borders</h2>
<p class="text-gray-300 text-lg mb-8 max-w-lg">
            Combining six decades of industrial heritage with state-of-the-art logistics technology.
          </p>
<!-- Tracking Input Box -->
<div class="bg-white/10 backdrop-blur-md p-4 rounded-lg border border-white/20 mb-6 max-w-lg">
<div class="flex gap-2">
<div class="relative flex-1">
<span class="absolute left-3 top-3.5 text-gray-400">
<svg class="w-5 h-5" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
</span>
<input class="w-full pl-10 py-3 bg-white text-gray-900 rounded-md focus:ring-2 focus:ring-brand-orange border-none outline-none" placeholder="Enter Tracking Number" type="text"/>
</div>
<button class="bg-brand-orange px-8 py-3 rounded-md font-bold hover:bg-orange-600 transition whitespace-nowrap">Track Shipment</button>
</div>
</div>
<!-- Tracking Result Card -->
<div class="bg-white rounded-lg p-6 text-gray-900 shadow-xl max-w-md">
<div class="flex items-center gap-2 mb-6">
<div class="w-6 h-6 bg-orange-100 flex items-center justify-center rounded-full">
<svg class="w-4 h-4 text-brand-orange" fill="currentColor" viewbox="0 0 20 20"><path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"></path><path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05a2.5 2.5 0 014.9 0H18a1 1 0 001-1V9.414a1 1 0 00-.293-.707l-2-2A1 1 0 0016 6.5h-2z"></path></svg>
</div>
<span class="font-bold text-sm tracking-wide">Tracking: <span class="text-brand-orange uppercase">JRS-9823-XYZ</span></span>
</div>
<!-- Stepper Container -->
<div class="relative flex justify-between mb-8 px-4">
<div class="stepper-line"></div>
<div class="stepper-line stepper-line-active"></div>
<!-- Step 1 -->
<div class="relative z-10 flex flex-col items-center">
<div class="w-6 h-6 rounded-full bg-brand-orange flex items-center justify-center text-white">
<svg class="w-4 h-4" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M5 13l4 4L19 7" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"></path></svg>
</div>
<span class="text-[10px] font-bold mt-2 uppercase text-gray-400">Picked</span>
</div>
<!-- Step 2 -->
<div class="relative z-10 flex flex-col items-center">
<div class="w-6 h-6 rounded-full bg-brand-orange border-2 border-white shadow-md flex items-center justify-center text-white">
<div class="w-2 h-2 bg-white rounded-full"></div>
</div>
<span class="text-[10px] font-bold mt-2 uppercase text-brand-orange">In Transit</span>
</div>
<!-- Step 3 -->
<div class="relative z-10 flex flex-col items-center">
<div class="w-6 h-6 rounded-full bg-gray-200 border-2 border-white"></div>
<span class="text-[10px] font-bold mt-2 uppercase text-gray-400">Delivered</span>
</div>
</div>
<p class="text-xs text-gray-500 text-center font-medium">Current Status: <span class="text-gray-900 font-bold">Arrived at Pasay Hub</span></p>
</div>
</div>
<!-- Right Side: Quick Calculate -->
<div class="flex items-center justify-center lg:justify-end">
<div class="bg-white rounded-lg shadow-2xl w-full max-w-md p-8">
<div class="flex items-center gap-2 mb-6 text-brand-orange">
<svg class="w-5 h-5" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg>
<h3 class="text-xl font-bold uppercase tracking-tight text-gray-900">Quick Calculate</h3>
</div>
<form class="space-y-4" id="calcForm">
<div class="grid grid-cols-2 gap-4">
<div>
<label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Origin City</label>
<select class="w-full border-gray-200 rounded-md text-sm py-2">
<option>Metro Manila</option>
<option>Luzon</option>
<option>Visayas</option>
<option>Mindanao</option>
</select>
</div>
<div>
<label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Destination</label>
<select class="w-full border-gray-200 rounded-md text-sm py-2">
<option>Metro Manila</option>
<option>Luzon</option>
<option>Visayas</option>
<option>Mindanao</option>
</select>
</div>
</div>
<div class="grid grid-cols-2 gap-4">
<div>
<label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Weight (kg)</label>
<input class="w-full border-gray-200 rounded-md text-sm py-2" id="calcWeight" placeholder="0.5" step="0.1" type="number" value="0.5"/>
</div>
<div>
<label class="block text-[10px] font-bold text-gray-500 uppercase mb-1">Service Type</label>
<select class="w-full border-gray-200 rounded-md text-sm py-2">
<option>Express Letter</option>
<option>One Pounder</option>
<option>Five Pounder</option>
<option>Bulilit Box</option>
</select>
</div>
</div>
<button class="w-full bg-slate-700 text-white font-bold py-3 rounded-md mt-4 hover:bg-slate-800 transition uppercase tracking-wide text-sm shadow-md" id="calcBtn" type="button">
                Calculate Estimate
              </button>
<!-- Result Box -->
<div class="hidden mt-4 p-4 bg-orange-50 border border-orange-100 rounded-md text-center" id="calcResult">
<p class="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Estimated Total</p>
<p class="text-2xl font-black text-brand-orange" id="calcValue">₱0.00</p>
</div>
</form>
</div>
</div>
</div>
</section>
<!-- END: Hero Section -->
<!-- BEGIN: Services Section -->
<section class="py-20 bg-white">
<div class="max-w-7xl mx-auto px-4">
<div class="text-center mb-12">
<h2 class="text-3xl font-black text-gray-900 mb-4 uppercase tracking-tight">Our Specialized Services</h2>
<p class="text-gray-500 max-w-2xl mx-auto">Tailored shipping solutions for every need, from urgent documents to bulk industrial cargo.</p>
</div>
<div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
<!-- Card 1 -->
<div class="group p-8 border border-gray-100 rounded-xl hover:border-brand-orange hover:shadow-card transition duration-300">
<div class="w-12 h-12 bg-orange-100 text-brand-orange flex items-center justify-center rounded-lg mb-6 group-hover:bg-brand-orange group-hover:text-white transition">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
</div>
<h4 class="text-lg font-bold mb-2">Express Letter</h4>
<p class="text-sm text-gray-500 mb-6 leading-relaxed">Next day delivery for your critical documents across the archipelago.</p>
<a class="text-brand-orange text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all" href="#">Learn More <svg class="w-3 h-3" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg></a>
</div>
<!-- Card 2 -->
<div class="group p-8 border border-gray-100 rounded-xl hover:border-brand-orange hover:shadow-card transition duration-300">
<div class="w-12 h-12 bg-orange-100 text-brand-orange flex items-center justify-center rounded-lg mb-6 group-hover:bg-brand-orange group-hover:text-white transition">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
</div>
<h4 class="text-lg font-bold mb-2">Pounders (1, 3, 5)</h4>
<p class="text-sm text-gray-500 mb-6 leading-relaxed">Standardized weight-based shipping pouches for maximum value.</p>
<a class="text-brand-orange text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all" href="#">Learn More <svg class="w-3 h-3" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg></a>
</div>
<!-- Card 3 -->
<div class="group p-8 border border-gray-100 rounded-xl hover:border-brand-orange hover:shadow-card transition duration-300">
<div class="w-12 h-12 bg-orange-100 text-brand-orange flex items-center justify-center rounded-lg mb-6 group-hover:bg-brand-orange group-hover:text-white transition">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
</div>
<h4 class="text-lg font-bold mb-2">Bulilit Boxes</h4>
<p class="text-sm text-gray-500 mb-6 leading-relaxed">Compact box solutions for e-commerce sellers and small parcels.</p>
<a class="text-brand-orange text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all" href="#">Learn More <svg class="w-3 h-3" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg></a>
</div>
<!-- Card 4 -->
<div class="group p-8 border border-gray-100 rounded-xl hover:border-brand-orange hover:shadow-card transition duration-300">
<div class="w-12 h-12 bg-orange-100 text-brand-orange flex items-center justify-center rounded-lg mb-6 group-hover:bg-brand-orange group-hover:text-white transition">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"></path><path d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0"></path></svg>
</div>
<h4 class="text-lg font-bold mb-2">Cargo Forwarding</h4>
<p class="text-sm text-gray-500 mb-6 leading-relaxed">Heavy-duty transport for industrial equipment and large-scale inventory.</p>
<a class="text-brand-orange text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all" href="#">Learn More <svg class="w-3 h-3" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg></a>
</div>
</div>
</div>
</section>
<!-- END: Services Section -->
<!-- BEGIN: Branch Locator Section -->
<section class="py-20 bg-orange-50">
<div class="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center">
<!-- Left: Search & List -->
<div>
<h2 class="text-3xl font-black text-gray-900 mb-4 uppercase tracking-tight">Find Your Nearest JRS Branch</h2>
<p class="text-gray-500 mb-8 max-w-lg">With over 400 branches nationwide, industrial-grade logistics support is always within reach.</p>
<!-- Search Box -->
<div class="mb-8">
<div class="relative mb-4">
<span class="absolute left-4 top-3 text-gray-400">
<svg class="w-5 h-5" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
</span>
<select class="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-md focus:ring-brand-orange bg-white">
<option>Enter City or Zip Code...</option>
<option>Pasay City</option>
<option>Makati City</option>
<option>Quezon City</option>
<option>Manila City</option>
<option>Cebu City</option>
<option>Davao City</option>
</select>
</div>
<button class="w-full bg-brand-orange text-white font-bold py-3 rounded-md uppercase tracking-widest text-sm hover:bg-orange-600 transition shadow-lg">Search Branches</button>
</div>
<!-- Branch List -->
<div class="space-y-3 max-h-[500px] overflow-y-auto pr-4 custom-scrollbar">
<!-- Branch 1 -->
<div class="bg-white p-4 rounded-lg flex items-center justify-between border-l-4 border-brand-orange shadow-sm hover:shadow-md transition">
<div class="flex gap-4">
<div class="w-10 h-10 bg-orange-50 rounded flex items-center justify-center text-brand-orange">
<svg class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
</div>
<div>
<h5 class="font-bold text-gray-900">Pasay Main Hub</h5>
<p class="text-xs text-gray-500">Aurora Blvd, Pasay City</p>
<p class="text-[10px] font-bold text-green-600 mt-1">OPEN NOW</p>
</div>
</div>
<svg class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 5l7 7-7 7"></path></svg>
</div>
<!-- Branch 2 -->
<div class="bg-white p-4 rounded-lg flex items-center justify-between border-l-4 border-transparent hover:border-brand-orange shadow-sm hover:shadow-md transition">
<div class="flex gap-4">
<div class="w-10 h-10 bg-gray-50 rounded flex items-center justify-center text-gray-400">
<svg class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
</div>
<div>
<h5 class="font-bold text-gray-900">Makati Branch</h5>
<p class="text-xs text-gray-500">Ayala Ave, Makati City</p>
<p class="text-[10px] font-bold text-green-600 mt-1">OPEN NOW</p>
</div>
</div>
<svg class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 5l7 7-7 7"></path></svg>
</div>
<!-- Branch 3 -->
<div class="bg-white p-4 rounded-lg flex items-center justify-between border-l-4 border-transparent hover:border-brand-orange shadow-sm hover:shadow-md transition">
<div class="flex gap-4">
<div class="w-10 h-10 bg-gray-50 rounded flex items-center justify-center text-gray-400">
<svg class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
</div>
<div>
<h5 class="font-bold text-gray-900">Cebu Regional Hub</h5>
<p class="text-xs text-gray-500">Mandaue City, Cebu</p>
<p class="text-[10px] font-bold text-green-600 mt-1">OPEN NOW</p>
</div>
</div>
<svg class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 5l7 7-7 7"></path></svg>
</div>
<!-- Branch 4 -->
<div class="bg-white p-4 rounded-lg flex items-center justify-between border-l-4 border-transparent hover:border-brand-orange shadow-sm hover:shadow-md transition">
<div class="flex gap-4">
<div class="w-10 h-10 bg-gray-50 rounded flex items-center justify-center text-gray-400">
<svg class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
</div>
<div>
<h5 class="font-bold text-gray-900">Davao City Hub</h5>
<p class="text-xs text-gray-500">JP Laurel Ave, Davao City</p>
<p class="text-[10px] font-bold text-green-600 mt-1">OPEN NOW</p>
</div>
</div>
<svg class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M9 5l7 7-7 7"></path></svg>
</div>
</div>
</div>
<!-- Right: Interactive Map Style Graphic -->
<div class="relative">
<div class="aspect-square bg-gray-200 rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
<img alt="Interactive Map" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0vKEAXYKsR5gaB5_ftHrWKs-Zit_GNG45eG0y5OMmKV5ZoI1WoO_7woULiuglvc9ipL50jRR4VmsEb-T6v5ACpfCenNRcpHZAoL-Bu-7JqfhFIOsF3KvIUu9baruJ_FrnZiI4P_CPb36U9iVVTkG8r88K6ZW8q7rxBuEgvOj4smDhChFjgRB1ewWXjg6eaV1IuANN3CzfWjNKGyeA8iBpCLjHLrqpIy5b57epDb4Q7Nfc3jr5I4-IJrNXcUi7ikEFVIPD-9wq"/>
<!-- Floating Map Pins -->
<div class="absolute top-1/4 left-1/3 animate-bounce">
<svg class="w-8 h-8 text-brand-orange" fill="currentColor" viewbox="0 0 20 20"><path clip-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" fill-rule="evenodd"></path></svg>
</div>
<div class="absolute bottom-1/3 right-1/4 animate-pulse">
<svg class="w-10 h-10 text-brand-orange" fill="currentColor" viewbox="0 0 20 20"><path clip-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" fill-rule="evenodd"></path></svg>
<div class="absolute -top-10 -left-10 bg-white p-2 rounded shadow-lg text-[10px] font-bold whitespace-nowrap">Davao City Hub</div>
</div>
</div>
</div>
</div>
</section>
<!-- END: Branch Locator Section -->
<!-- BEGIN: Support & Stats Section -->
<section class="py-16 bg-white border-b border-gray-100">
<div class="max-w-7xl mx-auto px-4">
<div class="text-center mb-10">
<h3 class="text-2xl font-black text-gray-900 mb-2 uppercase">Need Industrial-Grade Support?</h3>
<p class="text-gray-500 mb-6">Our logistics experts are available to handle your corporate shipping accounts and individual tracking queries.</p>
<div class="flex flex-wrap justify-center gap-4">
<button class="flex items-center gap-2 px-6 py-2.5 border-2 border-gray-100 rounded-full font-bold text-sm text-gray-700 hover:border-brand-orange transition">
<svg class="w-4 h-4 text-brand-orange" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
              EMAIL SUPPORT
            </button>
<button class="flex items-center gap-2 px-6 py-2.5 border-2 border-gray-100 rounded-full font-bold text-sm text-gray-700 hover:border-brand-orange transition">
<svg class="w-4 h-4 text-brand-orange" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
              +63 2 8631 7351
            </button>
</div>
</div>
<!-- Stats Grid -->
<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
<div class="bg-gray-50 p-6 rounded-lg text-center border-b-2 border-transparent hover:border-brand-orange transition">
<div class="text-3xl font-black text-gray-900 mb-1">60+</div>
<div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Years Heritage</div>
</div>
<div class="bg-gray-50 p-6 rounded-lg text-center border-b-2 border-transparent hover:border-brand-orange transition">
<div class="text-3xl font-black text-gray-900 mb-1">400+</div>
<div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nationwide Points</div>
</div>
<div class="bg-gray-50 p-6 rounded-lg text-center border-b-2 border-transparent hover:border-brand-orange transition">
<div class="text-3xl font-black text-gray-900 mb-1">1M+</div>
<div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Monthly Shipments</div>
</div>
<div class="bg-gray-50 p-6 rounded-lg text-center border-b-2 border-transparent hover:border-brand-orange transition">
<div class="text-3xl font-black text-gray-900 mb-1">99.9%</div>
<div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Service Level</div>
</div>
</div>
</div>
</section>
<!-- END: Support & Stats Section -->
</main>
<!-- BEGIN: Footer -->
<footer class="bg-brand-gray pt-16 pb-8 border-t border-gray-200">
<div class="max-w-7xl mx-auto px-4">
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
<div class="lg:col-span-1">
<h2 class="text-xl font-black text-brand-orange mb-6">JRS LOGISTICS</h2>
<p class="text-sm text-gray-500 leading-relaxed">
            The leading courier and logistics provider in the Philippines, delivering excellence since 1960. Your partner in business and personal growth.
          </p>
</div>
<div>
<h6 class="font-bold text-xs text-gray-900 uppercase tracking-widest mb-6">Navigation</h6>
<ul class="space-y-4 text-sm text-gray-500">
<li><a class="hover:text-brand-orange transition" href="#">Tracking</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Branch Locator</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Rate Calculator</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Partner Portals</a></li>
</ul>
</div>
<div>
<h6 class="font-bold text-xs text-gray-900 uppercase tracking-widest mb-6">Compliance</h6>
<ul class="space-y-4 text-sm text-gray-500">
<li><a class="hover:text-brand-orange transition" href="#">Terms of Use</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Privacy Policy</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Data Security</a></li>
<li><a class="hover:text-brand-orange transition" href="#">Cargo Insurance</a></li>
</ul>
</div>
<div>
<h6 class="font-bold text-xs text-gray-900 uppercase tracking-widest mb-6">Connect</h6>
<ul class="space-y-4 text-sm text-gray-500">
<li class="flex items-center gap-2">
<svg class="w-4 h-4" fill="currentColor" viewbox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path></svg>
<a class="hover:text-brand-orange transition" href="#">Facebook</a>
</li>
<li class="flex items-center gap-2">
<svg class="w-4 h-4" fill="currentColor" viewbox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.84 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"></path></svg>
<a class="hover:text-brand-orange transition" href="#">Twitter</a>
</li>
</ul>
</div>
</div>
<div class="pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
<p class="text-xs text-gray-400">© 2023 JRS Business Corp. All Rights Reserved.</p>
<div class="flex gap-6">
<img alt="Visa" class="grayscale h-8" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCInyb37jQVsFe48qSOdjK2vU6VVcm7Lj1_mUShzXJrpqkEc8rgyaapYvWAD3iAsJ_7T9t_m5qCa1BNDtzXettCmBTstY-ln45jdLez_yrSAj2b_xxe0PQI-jlHRJCsqqS2OqkGS8aVJmfzE5fHZ5bKzhYPqC_h0WUUI7yeWcQ_I5mU9Fipmj-aXljPzRIWbKT6n0r66YZBV5hcdIBz_NB-eHUrwYyRGXBIre7EumsxBIUsls6vqckG7NMj0r1avuqA-clicgds"/>
<img alt="Mastercard" class="grayscale h-8" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA41peLUlM_JI-Ag1ADjjM-hHtsLCXbhNyF5igpnF22SqWPTnXlJtIO9UWbwiFRTB8CcYYze1nvauId_9Yc0MQMfdw2R6sxUOHo2JTb1oT_cEJN1fsgZOP32n-y8v3ieRgfUM2SL4tl5LxqB3Z6d5OXq_oTdYP80j-XTDVuPdcjRxBFd9x-Oj6S4d8zS4fH1WHCHOt72FRq_T4rNkUHcX4JK-m8b_4jcJEF5DIUrGZ-Aw77eQGbcc0k8E5YWg2sWyFIGzVnE0vA"/>
</div>
</div>
</div>
</footer>
<!-- END: Footer -->
<style data-purpose="scrollbar-styling">
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: #f3f4f6;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 10px;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
      background: #ee4d2d;
    }
  </style>
<script>
    document.getElementById('calcBtn').addEventListener('click', function() {
      const btn = this;
      const resultBox = document.getElementById('calcResult');
      const resultValue = document.getElementById('calcValue');
      const weight = parseFloat(document.getElementById('calcWeight').value) || 0;
      
      const originalText = btn.innerText;
      btn.innerText = 'Calculating...';
      btn.disabled = true;
      
      setTimeout(() => {
        const baseRate = 120; // Example base rate
        const perKg = 45;
        const total = baseRate + (weight * perKg);
        
        resultValue.innerText = '₱' + total.toFixed(2);
        resultBox.classList.remove('hidden');
        
        btn.innerText = originalText;
        btn.disabled = false;
      }, 800);
    });
  </script>
</body></html>