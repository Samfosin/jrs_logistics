<?php
// functions/shipment_function.php
require_once __DIR__ . '/../config/db_connect.php';

/**
 * Create a new shipment booking
 */
function createShipment($data) {
    global $pdo;
    $tracking_num = 'JRS-' . strtoupper(bin2hex(random_bytes(4)));

    $sql  = "INSERT INTO shipments
                (tracking_number, sender_id, origin_branch_id, destination_address,
                 receiver_name, receiver_phone, service_type_id, weight, total_cost, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'picked_up')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $tracking_num,
        $data['sender_id'],
        $data['origin_branch_id'] ?? null,
        $data['destination_address'],
        $data['receiver_name'],
        $data['receiver_phone'],
        $data['service_type_id'],
        $data['weight'],
        $data['total_cost'],
    ]);

    // Log the initial status
    $shipment_id = $pdo->lastInsertId();
    $sql2 = "INSERT INTO tracking_logs (shipment_id, status, location, updated_by)
             VALUES (?, 'picked_up', 'Origin Branch', ?)";
    $pdo->prepare($sql2)->execute([$shipment_id, $data['sender_id']]);

    return $tracking_num;
}

/**
 * Get shipment details by tracking number
 */
function getShipmentByTracking($tracking_number) {
    global $pdo;
    $sql  = "SELECT s.*, sr.service_name
             FROM shipments s
             JOIN service_rates sr ON s.service_type_id = sr.id
             WHERE s.tracking_number = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tracking_number]);
    return $stmt->fetch();
}

/**
 * Get all shipments for a specific client
 */
function getShipmentsByClient($user_id) {
    global $pdo;
    $sql  = "SELECT s.*, sr.service_name
             FROM shipments s
             JOIN service_rates sr ON s.service_type_id = sr.id
             WHERE s.sender_id = ?
             ORDER BY s.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

/**
 * Get tracking logs for a shipment
 */
function getTrackingLogs($shipment_id) {
    global $pdo;
    $sql  = "SELECT tl.*, u.name as updated_by_name
             FROM tracking_logs tl
             JOIN users u ON tl.updated_by = u.id
             WHERE tl.shipment_id = ?
             ORDER BY tl.timestamp DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$shipment_id]);
    return $stmt->fetchAll();
}

/**
 * Update shipment status and log it
 */
function updateShipmentStatus($shipment_id, $status, $location, $user_id) {
    global $pdo;
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE shipments SET status = ? WHERE id = ?")
            ->execute([$status, $shipment_id]);
        $pdo->prepare("INSERT INTO tracking_logs (shipment_id, status, location, updated_by) VALUES (?, ?, ?, ?)")
            ->execute([$shipment_id, $status, $location, $user_id]);
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        return false;
    }
}

/**
 * Get all shipments (admin view)
 */
function getAllShipments() {
    global $pdo;
    $sql  = "SELECT s.*, sr.service_name, u.name as sender_name
             FROM shipments s
             JOIN service_rates sr ON s.service_type_id = sr.id
             JOIN users u ON s.sender_id = u.id
             ORDER BY s.created_at DESC";
    return $pdo->query($sql)->fetchAll();
}