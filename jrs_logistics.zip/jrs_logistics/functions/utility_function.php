<?php
// functions/utility_function.php

/** Format currency to Philippine Peso */
function formatPHP($amount) {
    return '₱' . number_format((float)$amount, 2);
}

/** Sanitize input data */
function clean($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

/** Format date for display */
function formatDate($timestamp) {
    return date('M d, Y h:i A', strtotime($timestamp));
}

/** Status badge helper */
function statusBadge($status) {
    $map = [
        'picked_up'  => ['bg-secondary', 'PICKED UP'],
        'at_hub'     => ['bg-warning text-dark', 'AT HUB'],
        'sorting'    => ['bg-info text-dark', 'SORTING'],
        'in_transit' => ['bg-primary', 'IN TRANSIT'],
        'delivered'  => ['bg-success', 'DELIVERED'],
    ];
    [$cls, $label] = $map[$status] ?? ['bg-secondary', strtoupper($status)];
    return "<span class=\"badge {$cls} px-3\">{$label}</span>";
}