<?php
// functions/rate_functions.php
require_once __DIR__ . '/../config/db_connect.php';

/**
 * Get all available service rates
 */
function getAllRates() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM service_rates ORDER BY base_rate ASC");
    return $stmt->fetchAll();
}

/**
 * Update a service rate
 */
function updateRate($id, $base, $per_kg) {
    global $pdo;
    $sql = "UPDATE service_rates SET base_rate = ?, per_kg_rate = ? WHERE id = ?";
    return $pdo->prepare($sql)->execute([$base, $per_kg, $id]);
}
?>