<?php
// config/constants.php
define('APP_NAME', 'JRS Logistics Portal');
define('BASE_URL', 'http://localhost/jrs_logistics/');

// Service Types for reference
define('SERVICE_EXPRESS', 1);
define('SERVICE_POUNDER', 2);
define('SERVICE_BULILIT', 3);
define('SERVICE_CARGO', 4);
?>