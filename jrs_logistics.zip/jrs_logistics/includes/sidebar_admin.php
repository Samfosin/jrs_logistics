<!-- includes/sidebar_admin.php -->
<div class="d-flex flex-column flex-shrink-0 p-3 bg-white border-end" style="width:260px;min-height:100vh;">
    <div class="mb-4 px-2">
        <h5 class="fw-bold text-primary mb-0">JRS LOGISTICS</h5>
        <small class="text-muted">Admin Portal</small>
    </div>
    <ul class="nav nav-pills flex-column mb-auto gap-1">
        <li class="nav-item">
            <a href="/jrs_logistics/modules/admin/dashboard.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="bar-chart-3" class="me-2"></i> Analytics
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/admin/user_mgmt.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='user_mgmt.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="users" class="me-2"></i> User Management
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/admin/rates.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='rates.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="dollar-sign" class="me-2"></i> Rates &amp; Tariffs
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/admin/claims.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='claims.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="shield-alert" class="me-2"></i> Claims
            </a>
        </li>
    </ul>
    <hr>
    <div class="dropdown p-2 bg-light rounded-4">
        <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name'] ?? 'Admin'); ?>&background=1a1c1e&color=fff"
                 alt="" width="32" height="32" class="rounded-circle me-2">
            <strong class="text-truncate" style="max-width:140px;"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?></strong>
        </a>
        <ul class="dropdown-menu shadow">
            <li><a class="dropdown-item" href="/jrs_logistics/modules/auth/logout.php">Sign out</a></li>
        </ul>
    </div>
</div>