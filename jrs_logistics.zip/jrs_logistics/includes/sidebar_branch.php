<!-- includes/sidebar_branch.php -->
<div class="d-flex flex-column flex-shrink-0 p-3 bg-white border-end" style="width:260px;min-height:100vh;">
    <div class="mb-4 px-2">
        <h5 class="fw-bold text-primary mb-0">JRS LOGISTICS</h5>
        <small class="text-muted">Branch Operator</small>
    </div>
    <ul class="nav nav-pills flex-column mb-auto gap-1">
        <li class="nav-item">
            <a href="/jrs_logistics/modules/branch/dashboard.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="layout-dashboard" class="me-2"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/branch/inventory.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='inventory.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="package" class="me-2"></i> Inventory
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/branch/dispatch.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='dispatch.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="truck" class="me-2"></i> Dispatch
            </a>
        </li>
        <li>
            <a href="/jrs_logistics/modules/branch/reports.php"
               class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'link-dark'; ?> py-3 rounded-4">
                <i data-lucide="file-text" class="me-2"></i> Daily Reports
            </a>
        </li>
    </ul>
    <hr>
    <div class="dropdown p-2 bg-light rounded-4">
        <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name'] ?? 'Branch'); ?>&background=ee4d2d&color=fff"
                 alt="" width="32" height="32" class="rounded-circle me-2">
            <strong class="text-truncate" style="max-width:140px;"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Branch Staff'); ?></strong>
        </a>
        <ul class="dropdown-menu shadow">
            <li><a class="dropdown-item" href="/jrs_logistics/modules/auth/logout.php">Sign out</a></li>
        </ul>
    </div>
</div>