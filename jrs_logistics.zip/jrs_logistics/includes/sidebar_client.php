<!-- includes/sidebar_client.php -->
<div class="offcanvas-md offcanvas-start bg-white border-end" tabindex="-1" id="sidebarMenu" style="width:260px;min-height:100vh;">
    <div class="d-flex flex-column p-3 h-100">
        <div class="mb-4 px-2 d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold text-primary mb-0">JRS LOGISTICS</h5>
                <small class="text-muted">Sender Module</small>
            </div>
            <button type="button" class="btn-close d-md-none" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu"></button>
        </div>
        <ul class="nav nav-pills flex-column mb-auto gap-1">
            <li class="nav-item">
                <a href="/jrs_logistics/modules/client/dashboard.php"
                   class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'link-dark'; ?> py-3 rounded-3 d-flex align-items-center">
                    <i data-lucide="layout-dashboard" class="me-3" size="20"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="/jrs_logistics/modules/client/history.php"
                   class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='history.php'?'active':'link-dark'; ?> py-3 rounded-3 d-flex align-items-center">
                    <i data-lucide="package" class="me-3" size="20"></i> Shipments
                </a>
            </li>
            <li>
                <a href="/jrs_logistics/modules/client/book_shipment.php"
                   class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='book_shipment.php'?'active':'link-dark'; ?> py-3 rounded-3 d-flex align-items-center fw-bold">
                    <i data-lucide="plus-square" class="me-3" size="20"></i> Book Now
                </a>
            </li>
            <li>
                <a href="/jrs_logistics/modules/client/claims.php"
                   class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='claims.php'?'active':'link-dark'; ?> py-3 rounded-3 d-flex align-items-center">
                    <i data-lucide="shield-alert" class="me-3" size="20"></i> Claims
                </a>
            </li>
            <li>
                <a href="/jrs_logistics/modules/client/profile.php"
                   class="nav-link <?php echo basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'link-dark'; ?> py-3 rounded-3 d-flex align-items-center">
                    <i data-lucide="user" class="me-3" size="20"></i> My Profile
                </a>
            </li>
        </ul>
        <hr>
        <div class="dropdown p-2 bg-light rounded-3">
            <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name'] ?? 'User'); ?>&background=ee4d2d&color=fff"
                     alt="" width="32" height="32" class="rounded-circle me-2">
                <strong class="text-truncate" style="max-width:150px;"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Client'); ?></strong>
            </a>
            <ul class="dropdown-menu shadow">
                <li><a class="dropdown-item" href="/jrs_logistics/modules/client/profile.php">Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="/jrs_logistics/modules/auth/logout.php">Sign out</a></li>
            </ul>
        </div>
    </div>
</div>