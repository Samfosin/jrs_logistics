<?php // includes/footer.php ?>
<footer class="bg-white border-top py-5 mt-auto">
    <div class="container">
        <div class="row align-items-center justify-content-between text-center text-md-start">
            <div class="col-md-4 mb-4 mb-md-0">
                <h2 class="fw-bold mb-3">JRS LOGISTICS</h2>
                <p class="text-muted small">Industrial Heritage &amp; Modern Speed. Serving the Philippines with reliable logistics solutions for over six decades.</p>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-4">
                        <h6 class="fw-bold">Company</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-decoration-none text-muted">Tracking</a></li>
                            <li><a href="#" class="text-decoration-none text-muted">Branch Locator</a></li>
                            <li><a href="#" class="text-decoration-none text-muted">Our Story</a></li>
                        </ul>
                    </div>
                    <div class="col-4">
                        <h6 class="fw-bold">Legal</h6>
                        <ul class="list-unstyled small">
                            <li><a href="#" class="text-decoration-none text-muted">Terms</a></li>
                            <li><a href="#" class="text-decoration-none text-muted">Privacy</a></li>
                            <li><a href="#" class="text-decoration-none text-muted">Sitemap</a></li>
                        </ul>
                    </div>
                    <div class="col-4">
                        <h6 class="fw-bold">Contact</h6>
                        <ul class="list-unstyled small text-muted">
                            <li>Support Center</li>
                            <li>+63 2 8631-7351</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <hr class="my-4">
        <div class="text-center text-muted small">
            &copy; <?php echo date('Y'); ?> JRS Express Logistics. All rights reserved.
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>lucide.createIcons();</script>
</body>
</html>