<?php
// includes/auth_check.php
if (session_status() === PHP_SESSION_NONE) session_start();

/** Check if user is logged in */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/** Redirect if not authorized for role */
function restrict_to($role) {
    if (!is_logged_in()) {
        header("Location: /jrs_logistics/modules/auth/login.php");
        exit();
    }
    if ($_SESSION['user_role'] !== $role) {
        http_response_code(403);
        die("<div style='font-family:sans-serif;text-align:center;padding:80px'>
             <h2>Access Denied</h2><p>You do not have permission to view this page.</p>
             <a href='/jrs_logistics/index.php'>Go Home</a></div>");
    }
}