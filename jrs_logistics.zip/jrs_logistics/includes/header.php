<?php
// includes/header.php
$current_dir = dirname($_SERVER['PHP_SELF']);
$dir_parts = explode('/', trim($current_dir, '/'));
$project_index = array_search('jrs_logistics', $dir_parts);
$levels_deep = ($project_index !== false) ? count($dir_parts) - $project_index - 1 : 0;
$base_path = str_repeat('../', $levels_deep);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JRS Logistics Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top py-3">
        <div class="container">
            <a class="navbar-brand fw-black text-primary" href="<?php echo $base_path; ?>index.php" style="color: #ee4d2d !important; font-weight: 900; font-size: 1.5rem;">JRS LOGISTICS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link fw-bold text-primary" href="<?php echo $base_path; ?>index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link fw-medium" href="<?php echo $base_path; ?>index.php#branch-locator">Branch Locator</a></li>
                    <li class="nav-item"><a class="nav-link fw-medium" href="<?php echo $base_path; ?>index.php#rates">Rates</a></li>
                    <li class="nav-item"><a class="nav-link fw-medium" href="<?php echo $base_path; ?>index.php#support">Support</a></li>
                </ul>
                <a href="<?php echo $base_path; ?>modules/auth/login.php" class="btn btn-primary px-4 fw-bold" style="background-color: #ee4d2d; border: none;">Log In</a>
            </div>
        </div>
    </nav>
    <script>lucide.createIcons();</script>